# PHP 7.4 Security Hardener v0.1.0

面向宝塔风格的 CentOS 7 + PHP 7.4.34 + PHP-FPM 安全配置工具。要求 Python 3.6+。

## 安全策略

- 默认只读扫描；只有显式传入 `--apply` 才修改配置。
- 修改前备份 `/www/server/php/74/etc/php.ini` 和 `php-fpm.conf`。
- 低风险加固：`display_errors=Off`、`display_startup_errors=Off`、`session.upload_progress.enabled=Off`。
- FPM pool 的 `security.limit_extensions` 收紧为 `.php`，避免将 `.phar/.pha` 作为 FPM 脚本扩展。
- 通过 FPM `php_admin_flag` 锁定 `display_errors=Off` 与 `session.upload_progress.enabled=Off`，减少 `.user.ini` 或运行时配置覆盖的机会。
- 测试 `php-fpm -tt` 后，调用 `/etc/init.d/php-fpm-74 reload` 平滑重载；失败时恢复备份。
- 不修改 `memory_limit`、`post_max_size`、`upload_max_filesize`，不禁用 PHP 函数，不改文件权限。

## 使用

```bash
python3 php74_hardener.py                 # 只读扫描
python3 php74_hardener.py --apply         # 备份并加固
python3 php74_hardener.py --rollback      # 回滚最近一次备份
```

备份目录：`/root/php74-hardener-backups/`

## CVE 与补丁状态说明

配置加固不能代替 PHP 源码补丁。PHP 7.4 的 PHP 官方安全团队曾提供针对 CVE-2026-109618/109619 的最小回补分支/提交；宝塔当前二进制是否已包含回补，不能从 `PHP 7.4.34` 版本号或编译日期确认。工具会检查 `max_multipart_body_parts` 作为线索，但它不是完整的补丁证明。

不要盲目把 `memory_limit=-1` 写入生产环境。PHP 官方将其列为 CVE-2026-109618 的临时缓解思路，但要求配合 cgroup/容器级内存边界；该服务器当前配置有 80 个 FPM children，因此必须先评估 RAM、单 Worker 峰值和可用的 cgroup 控制，再决定是否设置。上传限制也保持原来的 50M，避免未经确认就破坏网站上传功能。

长期建议迁移到受支持的 Linux 与 PHP 分支。CentOS 7 已于 2024-06-30 EOL；PHP 7.4 已结束官方常规支持。
