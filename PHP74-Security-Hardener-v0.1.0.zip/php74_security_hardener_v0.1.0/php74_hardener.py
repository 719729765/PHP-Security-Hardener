#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""PHP 7.4 security hardener for aaPanel/BT-style CentOS installations.
Python 3.6 compatible. Default mode is read-only scan; --apply is explicit.
"""
from __future__ import print_function
import argparse
import datetime
import glob
import os
import re
import shutil
import subprocess
import sys
import tempfile

PHP_ROOT = "/www/server/php/74"
PHP_BIN = os.path.join(PHP_ROOT, "bin/php")
FPM_BIN = os.path.join(PHP_ROOT, "sbin/php-fpm")
PHP_INI = os.path.join(PHP_ROOT, "etc/php.ini")
FPM_CONF = os.path.join(PHP_ROOT, "etc/php-fpm.conf")
INIT_SCRIPT = "/etc/init.d/php-fpm-74"
BACKUP_ROOT = "/root/php74-hardener-backups"

# Deliberately conservative: no memory_limit, upload-size, or function-list changes.
PHP_INI_UPDATES = {
    "display_errors": "Off",
    "display_startup_errors": "Off",
    "session.upload_progress.enabled": "Off",
}


def run(cmd, timeout=40):
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        out, _ = p.communicate(timeout=timeout)
        if not isinstance(out, str):
            out = out.decode("utf-8", "replace")
        return p.returncode, out
    except Exception as exc:
        return 998, str(exc)


def heading(text):
    print("\n========== %s ==========" % text)


def read_text(path):
    with open(path, "r") as f:
        return f.read()


def atomic_write(path, text, mode=None):
    st = os.stat(path)
    directory = os.path.dirname(path)
    fd, tmp = tempfile.mkstemp(prefix=".php74-hardener-", dir=directory)
    try:
        with os.fdopen(fd, "w") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, mode if mode is not None else (st.st_mode & 0o7777))
        try:
            os.chown(tmp, st.st_uid, st.st_gid)
        except Exception:
            pass
        os.rename(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def set_ini_directive(text, key, value):
    """Replace active or commented directive occurrences; append if absent."""
    lines = text.splitlines(True)
    pattern = re.compile(r"^\s*;?\s*" + re.escape(key) + r"\s*=", re.I)
    found = False
    result = []
    for line in lines:
        if pattern.match(line):
            # Only update the first matching location; comment duplicate copies.
            if not found:
                indent = re.match(r"^\s*", line).group(0)
                result.append("%s%s = %s\n" % (indent, key, value))
                found = True
            else:
                if line.lstrip().startswith(";"):
                    result.append(line)
                else:
                    result.append("; php74-hardener duplicate disabled: " + line)
        else:
            result.append(line)
    if not found:
        if result and not result[-1].endswith("\n"):
            result[-1] += "\n"
        result.append("\n; PHP74 Security Hardener managed setting\n%s = %s\n" % (key, value))
    return "".join(result)


def set_fpm_pool_directives(text, updates):
    lines = text.splitlines(True)
    in_www = False
    seen = set()
    result = []
    patterns = {key: re.compile(r"^\s*;?\s*" + re.escape(key) + r"\s*=", re.I)
                for key in updates}
    for line in lines:
        sm = re.match(r"^\s*\[([^]]+)\]", line)
        if sm:
            if in_www:
                for key, value in updates.items():
                    if key not in seen:
                        result.append("%s = %s\n" % (key, value))
                        seen.add(key)
            in_www = sm.group(1).strip().lower() == "www"
            result.append(line)
            continue
        if in_www:
            matched = None
            for key, pattern in patterns.items():
                if pattern.match(line):
                    matched = key
                    break
            if matched:
                if matched not in seen:
                    result.append("%s = %s\n" % (matched, updates[matched]))
                    seen.add(matched)
                else:
                    result.append("; php74-hardener duplicate disabled: " + line)
                continue
        result.append(line)
    if in_www:
        for key, value in updates.items():
            if key not in seen:
                result.append("%s = %s\n" % (key, value))
                seen.add(key)
    if len(seen) != len(updates):
        raise RuntimeError("在 php-fpm.conf 中找不到 [www] pool，拒绝自动修改")
    return "".join(result)


def php_info():
    rc, out = run([FPM_BIN, "-i"], 35)
    if rc != 0:
        return "", out
    return out, out


def effective_ini(info, key):
    pat = re.compile(r"^" + re.escape(key) + r"\s*=>\s*(.*?)\s*=>", re.I | re.M)
    m = pat.search(info)
    return m.group(1).strip() if m else "未读取到"


def current_patch_hint():
    rc, out = run([PHP_BIN, "-r", 'var_export(ini_get("max_multipart_body_parts"));'], 10)
    if rc == 0:
        val = out.strip().splitlines()[-1] if out.strip() else ""
        if val and val not in ("false", "NULL", "''", '""'):
            return "检测到 max_multipart_body_parts=%s；可能含 2026 PHP 7.4 安全回补特征，但不能仅凭此项证明所有补丁完整。" % val
        return "未检测到 max_multipart_body_parts；当前构建可能没有 PHP 7.4 官方 CVE-2026-109618/109619 回补。需核实编译来源。"
    return "无法读取 max_multipart_body_parts；需人工核实构建补丁。"


def scan():
    heading("系统与 PHP 环境")
    print("操作系统：")
    rc, out = run(["bash", "-c", "cat /etc/os-release | grep -E '^(NAME|VERSION|VERSION_ID)='"], 5)
    print(out.strip() or "未知")
    for path in (PHP_BIN, FPM_BIN, PHP_INI, FPM_CONF, INIT_SCRIPT):
        print("%-18s %s" % ("存在" if os.path.exists(path) else "缺失", path))
    if not all(os.path.exists(p) for p in (PHP_BIN, FPM_BIN, PHP_INI, FPM_CONF, INIT_SCRIPT)):
        print("\n环境不完整；工具不会执行修改。")
        return 2
    rc, out = run([PHP_BIN, "-v"], 10)
    print("PHP CLI：" + (out.splitlines()[0] if out else "未知"))
    info, _ = php_info()
    heading("FPM 当前生效值")
    for k in ("display_errors", "display_startup_errors", "session.upload_progress.enabled",
              "allow_url_include", "expose_php", "log_errors", "memory_limit",
              "post_max_size", "upload_max_filesize"):
        print("%-38s %s" % (k, effective_ini(info, k)))
    heading("FPM 配置检查")
    rc, out = run([FPM_BIN, "-tt"], 20)
    print("php-fpm -tt：%s" % ("通过" if rc == 0 else "失败"))
    m = re.search(r"security\.limit_extensions\s*=\s*(.*)", out)
    print("security.limit_extensions：" + (m.group(1).strip() if m else "未检测到"))
    for key in ("php_admin_flag[display_errors]", "php_admin_flag[session.upload_progress.enabled]"):
        km = re.search(re.escape(key) + r"\s*=\s*(.*)", out, re.I)
        print("%-48s %s" % (key, km.group(1).strip() if km else "未检测到"))
    print("clear_env：" + (re.search(r"clear_env\s*=\s*(.*)", out).group(1).strip() if re.search(r"clear_env\s*=\s*(.*)", out) else "未检测到"))
    print("listen.mode：" + (re.search(r"listen\.mode\s*=\s*(.*)", out).group(1).strip() if re.search(r"listen\.mode\s*=\s*(.*)", out) else "未检测到"))
    heading("CVE 回补线索")
    print(current_patch_hint())
    heading("建议")
    print("1) display_errors 当前如为 On，应关闭。")
    print("2) 显式设置 session.upload_progress.enabled=Off。")
    print("3) 将 FPM security.limit_extensions 收紧为 .php，并用 php_admin_flag 锁定错误显示与 session 上传进度关闭。")
    print("4) 本工具不会擅自把 memory_limit 改成 -1，也不会修改 50M 上传限制。")
    print("5) PHP 7.4 / CentOS 7 已过生命周期；配置加固不能代替官方安全回补或迁移。")
    return 0


def backup_files():
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    dest = os.path.join(BACKUP_ROOT, stamp)
    os.makedirs(dest, mode=0o700, exist_ok=False)
    shutil.copy2(PHP_INI, os.path.join(dest, "php.ini"))
    shutil.copy2(FPM_CONF, os.path.join(dest, "php-fpm.conf"))
    with open(os.path.join(dest, "BACKUP_INFO.txt"), "w") as f:
        f.write("PHP74 Hardener backup\n")
        f.write("created=" + datetime.datetime.now().isoformat() + "\n")
        f.write("php_ini=" + PHP_INI + "\n")
        f.write("fpm_conf=" + FPM_CONF + "\n")
    return dest


def restore(backup):
    shutil.copy2(os.path.join(backup, "php.ini"), PHP_INI)
    shutil.copy2(os.path.join(backup, "php-fpm.conf"), FPM_CONF)


def reload_fpm():
    if not os.path.exists(INIT_SCRIPT):
        return 1, "缺少 FPM init 脚本"
    return run([INIT_SCRIPT, "reload"], 30)


def apply_changes():
    if os.geteuid() != 0:
        print("必须使用 root 执行 --apply")
        return 2
    for p in (PHP_INI, FPM_CONF, FPM_BIN, INIT_SCRIPT):
        if not os.path.exists(p):
            print("缺少必要文件：" + p)
            return 2
    backup = backup_files()
    print("备份目录：" + backup)
    try:
        ini_text = read_text(PHP_INI)
        for key, value in PHP_INI_UPDATES.items():
            ini_text = set_ini_directive(ini_text, key, value)
        fpm_text = set_fpm_pool_directives(read_text(FPM_CONF), {
            "security.limit_extensions": ".php",
            "php_admin_flag[display_errors]": "off",
            "php_admin_flag[session.upload_progress.enabled]": "off",
        })
        atomic_write(PHP_INI, ini_text)
        atomic_write(FPM_CONF, fpm_text)
        rc, out = run([FPM_BIN, "-tt"], 30)
        print(out[-5000:])
        if rc != 0:
            raise RuntimeError("PHP-FPM 配置测试失败")
        rc, out = reload_fpm()
        print(out)
        if rc != 0:
            raise RuntimeError("PHP-FPM reload 命令失败")
        # Verify the config values visible to FPM after reload.
        info, _ = php_info()
        checks = {
            "display_errors": "Off",
            "session.upload_progress.enabled": "Off",
        }
        failed = []
        for key, expected in checks.items():
            actual = effective_ini(info, key)
            print("验证 %-38s %s" % (key, actual))
            if actual.lower() != expected.lower():
                failed.append("%s=%s（预期%s）" % (key, actual, expected))
        rc2, out2 = run([FPM_BIN, "-tt"], 20)
        m = re.search(r"security\.limit_extensions\s*=\s*(.*)", out2)
        ext = m.group(1).strip() if m else "未检测到"
        print("验证 security.limit_extensions：" + ext)
        if ext != ".php":
            failed.append("security.limit_extensions 未生效")
        for key in ("php_admin_flag[display_errors]", "php_admin_flag[session.upload_progress.enabled]"):
            km = re.search(re.escape(key) + r"\s*=\s*(.*)", out2, re.I)
            if not km or km.group(1).strip().lower() not in ("off", "0", "no"):
                failed.append(key + " 未生效")
        if rc2 != 0:
            failed.append("FPM 配置测试复查失败")
        if failed:
            raise RuntimeError("修改后验证失败：" + "; ".join(failed))
        print("\n加固成功。备份保存在：" + backup)
        print("未修改 memory_limit、post_max_size、upload_max_filesize，也未禁用 PHP 函数。")
        return 0
    except Exception as exc:
        print("\n加固失败：" + str(exc))
        print("正在恢复配置备份……")
        try:
            restore(backup)
            rc, out = run([FPM_BIN, "-tt"], 30)
            print(out[-3000:])
            reload_fpm()
            print("已恢复原配置。备份目录：" + backup)
        except Exception as restore_exc:
            print("自动恢复也发生错误，请立即手动检查：" + str(restore_exc))
            print("原始备份位于：" + backup)
        return 1


def rollback_latest():
    if os.geteuid() != 0:
        print("必须使用 root 执行 --rollback")
        return 2
    candidates = sorted(glob.glob(os.path.join(BACKUP_ROOT, "*")))
    candidates = [p for p in candidates if os.path.isdir(p) and
                  os.path.isfile(os.path.join(p, "php.ini")) and
                  os.path.isfile(os.path.join(p, "php-fpm.conf"))]
    if not candidates:
        print("没有找到可用备份：" + BACKUP_ROOT)
        return 1
    backup = candidates[-1]
    safety = backup_files()
    print("回滚来源：" + backup)
    print("回滚前现状备份：" + safety)
    restore(backup)
    rc, out = run([FPM_BIN, "-tt"], 30)
    print(out[-3000:])
    if rc != 0:
        print("恢复后的配置测试失败；文件已恢复但请勿 reload。")
        return 1
    rc, out = reload_fpm()
    print(out)
    print("回滚完成。")
    return 0 if rc == 0 else 1


def main():
    ap = argparse.ArgumentParser(description="CentOS 7 宝塔 PHP 7.4 安全加固器（默认只读扫描）")
    ap.add_argument("--scan", action="store_true", help="只读扫描（默认）")
    ap.add_argument("--apply", action="store_true", help="备份后应用低风险配置加固并平滑 reload FPM")
    ap.add_argument("--rollback", action="store_true", help="回滚到最近一次加固前备份并 reload FPM")
    args = ap.parse_args()
    if args.apply and args.rollback:
        ap.error("--apply 和 --rollback 不能同时使用")
    if args.apply:
        return apply_changes()
    if args.rollback:
        return rollback_latest()
    return scan()


if __name__ == "__main__":
    sys.exit(main())
