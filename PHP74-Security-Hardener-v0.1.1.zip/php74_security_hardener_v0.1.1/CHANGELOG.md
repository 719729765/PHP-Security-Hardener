# Changelog

## v0.1.1
- Fixed false-negative validation of `php_admin_flag[...]` directives.
- `php-fpm -tt` remains the authoritative FPM syntax check.
- Pool admin flags and `security.limit_extensions` are now verified from the active `[www]` pool configuration file, rather than requiring vendor-specific diagnostic output to echo them.
- Kept automatic backup and rollback behavior unchanged.
