# PHP 7.4 Security Hardener v0.1.1

适配宝塔风格 CentOS 7 + PHP 7.4.34 + PHP-FPM，兼容 Python 3.6+。

## v0.1.1 修复

修复 v0.1.0 的验证器误判：部分 PHP-FPM 构建的 `php-fpm -tt` 输出不会回显 `php_admin_flag[...]` pool 指令。旧版程序把“诊断输出中未显示”误判为“指令未生效”，导致配置检查和 reload 成功后又自动回滚。

v0.1.1 改为：

- 通过 `php-fpm -tt` 检查 FPM 配置语法；
- 从实际 `[www]` pool 配置文件读取并核验 `php_admin_flag[...]` 与 `security.limit_extensions`；
- 仍使用 FPM `-i` 检查 php.ini 层的 `display_errors` 和 `session.upload_progress.enabled`；
- 缺少配置或 FPM 语法检查失败仍然回滚。

PHP 官方文档确认 `php_admin_flag` 是 PHP-FPM pool 的合法配置，且不能被 PHP 脚本中的 `ini_set()` 覆盖：<https://www.php.net/manual/en/install.fpm.configuration.php>。

## 安全策略

- 默认只读扫描；只有显式 `--apply` 才修改。
- 修改前备份 `php.ini` 和 `php-fpm.conf`。
- 修改 `display_errors=Off`、`display_startup_errors=Off`、`session.upload_progress.enabled=Off`。
- 在 `[www]` pool 中设置 `security.limit_extensions=.php` 及两个 `php_admin_flag`。
- FPM 配置测试和重载失败时恢复备份。
- 不修改 `memory_limit`、上传大小限制，不禁用 PHP 函数，不修改网站文件和权限。

## 使用

```bash
python3 php74_hardener.py                 # 只读扫描
python3 php74_hardener.py --apply         # 备份并加固
python3 php74_hardener.py --rollback      # 回滚最近一次备份
```

备份目录：`/root/php74-hardener-backups/`。

## 注意

配置加固不能替代 PHP 源码安全补丁，也不能替代从 CentOS 7 / PHP 7.4 迁移到受支持系统和 PHP 分支。
